using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RailwayReservationSystem.Models
{
    public class Schedule
{
    public int ScheduleId { get; set; }
    
    // Foreign key to Train
    public int TrainId { get; set; }
    public Train Train { get; set; }
    
    // Departure city
    public int DepartureCityId { get; set; }
    public City DepartureCity { get; set; }
    
    // Arrival city
    public int ArrivalCityId { get; set; }
    public City ArrivalCity { get; set; }
    
    public DateTime DepartureTime { get; set; }
    public DateTime ArrivalTime { get; set; }
}

}