﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RailwayReservationSystem.Migrations
{
    /// <inheritdoc />
    public partial class Updajj : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Schedule_City_CityId",
                table: "Schedule");

            migrationBuilder.RenameColumn(
                name: "CityId",
                table: "Schedule",
                newName: "DepartureCityId");

            migrationBuilder.RenameIndex(
                name: "IX_Schedule_CityId",
                table: "Schedule",
                newName: "IX_Schedule_DepartureCityId");

            migrationBuilder.AddColumn<int>(
                name: "ArrivalCityId",
                table: "Schedule",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Schedule_ArrivalCityId",
                table: "Schedule",
                column: "ArrivalCityId");

            migrationBuilder.AddForeignKey(
                name: "FK_Schedule_City_ArrivalCityId",
                table: "Schedule",
                column: "ArrivalCityId",
                principalTable: "City",
                principalColumn: "CityId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Schedule_City_DepartureCityId",
                table: "Schedule",
                column: "DepartureCityId",
                principalTable: "City",
                principalColumn: "CityId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Schedule_City_ArrivalCityId",
                table: "Schedule");

            migrationBuilder.DropForeignKey(
                name: "FK_Schedule_City_DepartureCityId",
                table: "Schedule");

            migrationBuilder.DropIndex(
                name: "IX_Schedule_ArrivalCityId",
                table: "Schedule");

            migrationBuilder.DropColumn(
                name: "ArrivalCityId",
                table: "Schedule");

            migrationBuilder.RenameColumn(
                name: "DepartureCityId",
                table: "Schedule",
                newName: "CityId");

            migrationBuilder.RenameIndex(
                name: "IX_Schedule_DepartureCityId",
                table: "Schedule",
                newName: "IX_Schedule_CityId");

            migrationBuilder.AddForeignKey(
                name: "FK_Schedule_City_CityId",
                table: "Schedule",
                column: "CityId",
                principalTable: "City",
                principalColumn: "CityId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
