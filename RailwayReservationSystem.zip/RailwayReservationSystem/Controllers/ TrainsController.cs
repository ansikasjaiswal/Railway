using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RailwayReservationSystem.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RailwayReservationSystem.Controllers
{
    [Route("[controller]")]
    public class TrainsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TrainsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Trains/Search
        [HttpGet("Search")]
        public IActionResult Search()
        {
            return View();
        }

        // POST: Trains/Search
        [HttpPost("Search")]
        public async Task<IActionResult> Search(string sourceCity, string destinationCity, DateTime date)
        {
            // Query schedules matching the criteria
            var schedules = await _context.Schedules
                .Include(s => s.Train)
                .Include(s => s.DepartureCity)
                .Include(s => s.ArrivalCity)
                .Where(s => s.DepartureCity.Name == sourceCity &&
                            s.ArrivalCity.Name == destinationCity &&
                            s.DepartureTime.Date == date.Date)
                .ToListAsync();

            // Pass the list of schedules to the view
            return View("SearchResults", schedules);
        }

        // GET: Trains/Details/5
        [HttpGet("Details/{id}")]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Retrieve the train and its schedules
            var train = await _context.Trains
                .Include(t => t.Schedules)
                .ThenInclude(s => s.DepartureCity)
                .Include(t => t.Schedules)
                .ThenInclude(s => s.ArrivalCity)
                .FirstOrDefaultAsync(m => m.TrainId == id);

            if (train == null)
            {
                return NotFound();
            }

            // Pass the train object to the view
            return View(train);
        }
    }
}
