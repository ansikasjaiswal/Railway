using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RailwayReservationSystem.Models;

namespace RailwayReservationSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<City> Cities { get; set; }
    public DbSet<Train> Trains { get; set; }
    public DbSet<Schedule> Schedules { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<City>().ToTable("City");
        modelBuilder.Entity<Train>().ToTable("Train");
        modelBuilder.Entity<Schedule>().ToTable("Schedule");

        modelBuilder.Entity<Schedule>()
            .HasOne(s => s.Train)
            .WithMany(t => t.Schedules)
            .HasForeignKey(s => s.TrainId);

        modelBuilder.Entity<Schedule>()
            .HasOne(s => s.DepartureCity)
            .WithMany()
            .HasForeignKey(s => s.DepartureCityId)
            .OnDelete(DeleteBehavior.Restrict); // Adjust cascade delete behavior as needed

        modelBuilder.Entity<Schedule>()
            .HasOne(s => s.ArrivalCity)
            .WithMany()
            .HasForeignKey(s => s.ArrivalCityId)
            .OnDelete(DeleteBehavior.Restrict);        
    }
}
}